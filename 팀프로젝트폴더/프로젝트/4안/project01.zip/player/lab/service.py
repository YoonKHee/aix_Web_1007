"""
감독 연구실 서비스 계층 (Django 사용 부분)

- 기록·일정·예측은 여기서 읽고, 계산은 chemistry / management / analysis (순수 파이썬)에 맡긴다.
- 화면은 선수 ID 목록만 보낸다. 서버가 DB에서 점수를 다시 계산하므로 브라우저에서 점수를 바꿔 보낼 수 없다.
- 피로도·경고 누적은 '모의 경기'에서 쌓이는 기록(브라우저가 보내는 mock_log)을 처음부터 다시 계산(replay)해서 얻는다. 서버에는 저장하지 않는다.
  (베스트11 화면은 그 결과를 읽어서 보여 주기만 하고, 피로를 쌓지는 않는다)
- 모든 수치는 올 시즌 기록 기반의 추정이며 '게임 규칙'을 포함한다. 실제 경기 결과를 보장하지 않는다.
"""

import glob
import os
import time
from datetime import date, timedelta

from django.conf import settings

from player.models import PlayerStats
from player import services as SV

from . import chemistry as CH
from . import management as MG
from . import analysis as AN
from . import club_profile as CP
from . import tuning as TU
from . import quality as QL

SEASON = 2026
CACHE_SECONDS = 300
# 소표본 보정: 출전 450분 미만 선수의 90분당 기록은 리그 평균 쪽으로 끌어당긴다. (450분 이상은 그대로)
#   보정값 = w × 본인 기록 + (1-w) × SHRINK_TARGET × 같은 포지션 평균,  w = 출전시간 / 450
SHRINK_ENABLED = True
SHRINK_FULL_MINUTES = 450
SHRINK_TARGET = 0.85          # 정보가 부족하면 평균보다 조금 낮게 본다
NO_SHRINK_METRICS = {'minutes'}
# 경험(출전시간) 보정: 출전시간이 EXPERIENCE_FULL 분에 못 미치면 능력 점수에 1 미만의 배율을 곱한다.
#   배율 = 1 - 감점폭 × (1 - 출전시간/EXPERIENCE_FULL),  감점폭 = (1 - EXPERIENCE_FLOOR) × 화면의 '경험 중시' 배율(0~2, 기본 1)
#   (경기 수는 출전시간과 거의 같이 움직이고, 교체로 잠깐 뛴 경기는 시간으로 걸러지므로 출전시간 하나로 본다)
EXPERIENCE_FULL = 1800        # 시즌의 약 60%: 이 이상 뛰면 감점 없음
EXPERIENCE_DEFAULT = 1.5      # '경험 중시' 기본 배율 (감점폭 0.30 × 1.5 = 최대 45% 감점, 출전 0분일 때)
EXPERIENCE_FLOOR = 0.70       # 출전시간 0분일 때의 배율(기본 설정)
CANDIDATE_LIMIT = 40
CONDITION_BAD_FATIGUE = 71            # 이 이상이면 모의 경기 컨디션을 '안 좋음' 으로 제안한다 (management 의 '기용 비권장' 구간)

METRIC_FUNCS = {'FW': SV.get_fw_metrics, 'MF': SV.get_mf_metrics, 'DF': SV.get_df_metrics, 'GK': SV.get_gk_metrics}
BASE_WEIGHTS = {'FW': SV.FW_WEIGHTS, 'MF': SV.MF_WEIGHTS, 'DF': SV.DF_WEIGHTS, 'GK': SV.GK_WEIGHTS}

METRIC_LABELS = {
    'goals': '득점', 'assists': '도움', 'shots_on_target': '유효슈팅', 'shots': '슈팅', 'key_passes': '키패스',
    'dribble': '드리블', 'pass_rate': '패스 성공률', 'recoveries': '볼 회수', 'interceptions': '인터셉트',
    'clearances': '클리어링', 'tackle': '태클', 'aerial_duel': '공중볼 경합', 'ground_duel': '지상 경합',
    'defensive_blocks': '수비 차단', 'blocks': '블록', 'rating': '평점', 'mom': 'MOM', 'best11': '베스트11 선정',
    'minutes': '출전시간',
}

# 프리셋 = 지표별 배율(없으면 1). 포지션 안에서 합계 100 으로 다시 맞춘다.
PRESETS = {
    'default': {'label': '기본', 'mult': {}},
    'attack': {'label': '공격 중시', 'mult': {'goals': 1.5, 'assists': 1.3, 'shots_on_target': 1.3, 'key_passes': 1.3, 'dribble': 1.3,
                                              'clearances': 0.7, 'blocks': 0.7, 'defensive_blocks': 0.7}},
    'defense': {'label': '수비 중시', 'mult': {'clearances': 1.4, 'interceptions': 1.4, 'tackle': 1.4, 'recoveries': 1.3,
                                              'aerial_duel': 1.3, 'ground_duel': 1.3, 'blocks': 1.3, 'defensive_blocks': 1.3,
                                              'goals': 0.7, 'shots': 0.7}},
    'build': {'label': '빌드업·점유', 'mult': {'pass_rate': 1.7, 'key_passes': 1.3, 'assists': 1.2, 'dribble': 0.8}},
    'press': {'label': '압박·볼 회수', 'mult': {'recoveries': 1.7, 'interceptions': 1.4, 'tackle': 1.4, 'ground_duel': 1.3, 'goals': 0.8}},
}

_cache = {'t': 0, 'data': None}


# ---------------------------------------------------------------- 데이터 로드

def _load():
    now = time.time()
    if _cache['data'] is not None and now - _cache['t'] < CACHE_SECONDS:
        return _cache['data']
    qs = (PlayerStats.objects.filter(season=SEASON, minutes__gt=0)
          .exclude(player_id__in=SV.EXCLUDED_PLAYER_IDS)
          .select_related('player', 'player__team'))
    rows, stats_by_id = [], {}
    for st in qs:
        pos = (st.player.position or '').strip().upper()
        if pos not in METRIC_FUNCS:
            continue
        row = {f: getattr(st, f, None) for f in CH.STAT_FIELDS}
        row.update(player_id=st.player_id, name=st.player.name, position=pos, team_id=st.player.team_id)
        rows.append(row)
        stats_by_id[st.player_id] = st
    club = CP.classify(CP.team_metrics([
        dict({k: getattr(st, k, 0) for k in CP.AGG_FIELDS}, team_id=st.player.team_id) for st in stats_by_id.values()]))
    for row in rows:
        ci = club.get(row['team_id'])
        row['club_style'] = ci['style'] if ci else None
        row['club_style_label'] = ci['label'] if ci else ''
    profiles = CH.build_profiles(rows)
    info = {}
    for pid, st in stats_by_id.items():
        pl = st.player
        photo = ''
        try:
            photo = pl.photo.url if pl.photo else ''
        except Exception:
            photo = ''
        logo = ''
        try:
            logo = pl.team.logo.url if pl.team_id and pl.team.logo else ''
        except Exception:
            logo = ''
        info[pid] = {'id': pid, 'team_logo': logo, 'name': pl.name, 'position': (pl.position or '').strip().upper(),
                     'team_id': pl.team_id, 'team': pl.team.team_name if pl.team_id else '',
                     'team_short': AN.short_name(pl.team.team_name) if pl.team_id else '',
                     'number': pl.number, 'photo': photo, 'birth_date': pl.birth_date,
                     'minutes': st.minutes, 'games': st.games, 'yellow': st.yellow_cards, 'red': st.red_cards}
    data = {'profiles': profiles, 'stats': stats_by_id, 'info': info, 'club': club}
    _cache.update(t=now, data=data)
    return data


def clear_cache():
    _cache.update(t=0, data=None)


# ---------------------------------------------------------------- 가중치와 능력 점수

def build_weights(preset='default', mult=None, extra=None):
    """지표 배율(프리셋 + 사용자가 조정한 값)을 적용한 포지션별 가중치(합계 100)."""
    pm = dict(PRESETS.get(preset, PRESETS['default'])['mult'])
    for k, v in (mult or {}).items():
        try:
            pm[k] = max(0.0, min(3.0, float(v)))
        except (TypeError, ValueError):
            pass
    for k, v in (extra or {}).items():            # 상대 맞춤 배율은 프리셋·사용자 조정 위에 곱한다
        pm[k] = pm.get(k, 1.0) * v
    out = {}
    for pos, base in BASE_WEIGHTS.items():
        raw = {m: w * pm.get(m, 1.0) for m, w in base.items()}
        total = sum(raw.values()) or 1.0
        out[pos] = {m: v / total * 100 for m, v in raw.items()}
    return out


def ability_scores(weights, shrink=None, exp_scale=None):
    exp_scale = EXPERIENCE_DEFAULT if exp_scale is None else exp_scale
    """{선수ID: 능력 점수}. 최고값 기준은 450분 이상 선수(사이트 BEST11 과 같은 기준)이다."""
    shrink = SHRINK_ENABLED if shrink is None else shrink
    data = _load()
    by_pos = {}
    for pid, st in data['stats'].items():
        by_pos.setdefault(st.player.position.strip().upper(), []).append((pid, st))
    ability = {}
    for pos, items in by_pos.items():
        fn, w = METRIC_FUNCS[pos], weights[pos]
        mets = {pid: fn(st) for pid, st in items}
        ref = [pid for pid, st in items if st.minutes >= SV.FORMATION_MIN_MINUTES] or [pid for pid, _ in items]
        maxes = {m: max((mets[pid][m] for pid in ref), default=0) for m in w}
        means = {m: sum(mets[pid][m] for pid in ref) / len(ref) for m in w}
        for pid, st in items:
            vals = mets[pid]
            if shrink and st.minutes < SHRINK_FULL_MINUTES:
                f = max(0.0, st.minutes) / SHRINK_FULL_MINUTES
                vals = {m: (vals[m] if m in NO_SHRINK_METRICS else f * vals[m] + (1 - f) * SHRINK_TARGET * means[m]) for m in vals}
            score = sum(SV.normalize_score(vals[m], maxes[m]) * w[m] / 100 for m in w)
            if exp_scale > 0 and st.minutes < EXPERIENCE_FULL:
                score *= max(0.0, 1 - (1 - EXPERIENCE_FLOOR) * exp_scale * (1 - max(0, st.minutes) / EXPERIENCE_FULL))
            ability[pid] = round(min(100.0, score), 2)
    return ability


# ---------------------------------------------------------------- 일정·예측

_sched = {'key': None, 'data': None}
_pred = {'obj': None, 'err': None}


def schedule():
    folder = os.path.join(str(settings.BASE_DIR), 'data', 'matches', '2026', 'official_verified')
    files = sorted(glob.glob(os.path.join(folder, 'official_source_*.json')))
    if not files:
        return None
    key = (files[-1], os.path.getmtime(files[-1]))
    if _sched['key'] != key:
        _sched.update(key=key, data=MG.load_schedule(files[-1]))
    return _sched['data']


def _forecast_tools():
    """팀원이 만든 team.match_prediction 을 그대로 사용한다. 못 불러오면 (None, 이유)."""
    if _pred['obj'] is None and _pred['err'] is None:
        try:
            from team import match_prediction as MP
            matches, sha = MP.load_matches()
            bundle = MP.load_bundle(sha)
            ids = {r['name']: r['id'] for r in MP.team_options(matches)}
            _pred['obj'] = (MP, matches, bundle, ids)
        except Exception as exc:
            _pred['err'] = str(exc)
    return _pred['obj'], _pred['err']


def _meta(info, today):
    return {str(pid): {'position': i['position'], 'age': MG.age_on(i['birth_date'], today), 'team': i['team_short'],
                       'season_yellow': i['yellow'], 'season_red': i['red'], 'season_minutes': i['minutes']}
            for pid, i in info.items()}


def _parse_date(v, default=None):
    try:
        return date.fromisoformat(str(v)[:10])
    except (TypeError, ValueError):
        return default


def clean_log(raw):
    """브라우저가 보낸 모의 경기 기록을 정리한다. 형식: [{'date':'YYYY-MM-DD','ids':[선수ID...]}] (최대 60건)"""
    out = []
    for e in (raw or [])[:60]:
        if not isinstance(e, dict):
            continue
        d = _parse_date(e.get('date'))
        ids = []
        for x in (e.get('ids') or [])[:60]:
            try:
                ids.append(int(x))
            except (TypeError, ValueError):
                pass
        if d and ids:
            out.append((d, ids))
    out.sort(key=lambda t: t[0])
    return out


def replay_mock(info, meta, log, target_date):
    """
    모의 경기 기록(log)을 날짜순으로 다시 계산해서 target_date 킥오프 직전의 상태를 돌려준다.
    - 경기에 나온 선수는 90분 출전(피로 누적, 연속 출전 횟수 +1).
    - 같은 경기에 나온 구단의 나머지 선수는 '쉬었음'으로 보고 연속 출전이 끊긴다.
    - 그 경기와 상관없는 구단 선수는 아무것도 바뀌지 않고, 시간이 지난 만큼만 회복한다.
    - target_date 이후(같은 날 포함)의 기록은 반영하지 않는다.
    """
    st_rows = [{'id': pid, 'position': i['position'], 'birth_date': i['birth_date'], 'minutes': i['minutes'],
                'games': i['games'], 'yellow_cards': i['yellow']} for pid, i in info.items()]
    state = MG.initial_state(st_rows)
    last = {}
    for d, ids in log:
        if d >= target_date:
            continue
        teams = {info[i]['team_id'] for i in ids if i in info}
        sub = {str(pid): state[str(pid)] for pid, i in info.items() if i['team_id'] in teams}
        days = {k: max(0, (d - last.get(k, d - timedelta(days=7))).days) for k in sub}
        played = {str(i): 90 for i in ids if str(i) in sub}
        new, _ = MG.advance_round(sub, played, meta, days)
        state.update(new)
        for k in sub:
            last[k] = d
    out = {}
    for k, v in state.items():
        gap = max(0, (target_date - last.get(k, target_date - timedelta(days=7))).days)
        out[k] = dict(v, fatigue=MG.pre_match_fatigue(v, gap, meta[k]['age']))
    return out


def goal_table(info):
    """{구단 DB id: {'gf': 경기당 득점, 'ga': 경기당 실점}} — 팀원의 경기 결과 파일에서. 못 읽으면 빈 dict."""
    pred, _err = _forecast_tools()
    if pred is None:
        return {}
    matches = pred[1]
    short_to_id = {}
    for i in info.values():
        if i['team_id']:
            short_to_id[i['team_short']] = i['team_id']
    acc = {}
    for m in matches:
        hg, ag = m.get('home_goals'), m.get('away_goals')
        if hg is None or ag is None:
            continue
        for team, gf, ga in ((m['home_team'], hg, ag), (m['away_team'], ag, hg)):
            tid = short_to_id.get(team)
            if tid:
                d = acc.setdefault(tid, {'gf': 0, 'ga': 0, 'n': 0})
                d['gf'] += gf
                d['ga'] += ga
                d['n'] += 1
    return {t: {'gf': d['gf'] / d['n'], 'ga': d['ga'] / d['n']} for t, d in acc.items() if d['n']}


# ---------------------------------------------------------------- 컨텍스트 (요청 하나의 계산 환경)

class Ctx:
    def __init__(self, body):
        self.data = _load()
        self.today = date.today()
        self.preset = body.get('preset', 'default')
        self.opponent = None
        extra, self.opp_reasons = {}, []
        try:
            opp = int(body.get('opponent')) if body.get('opponent') else None
        except (TypeError, ValueError):
            opp = None
        if opp and any(i['team_id'] == opp for i in self.data['info'].values()):
            self.opponent = opp
            extra, self.opp_reasons = TU.opponent_multipliers(opp, self.data['club'], goal_table(self.data['info']))
        self.opp_mult = extra
        self.weights = build_weights(self.preset, body.get('mult'), extra)
        try:
            self.exp_scale = max(0.0, min(2.0, float(body.get('exp_scale', EXPERIENCE_DEFAULT))))
        except (TypeError, ValueError):
            self.exp_scale = EXPERIENCE_DEFAULT
        self.ability = ability_scores(self.weights, exp_scale=self.exp_scale)
        try:
            self.chem_scale = max(0.0, min(2.0, float(body.get('chem_scale', 1.0))))
        except (TypeError, ValueError):
            self.chem_scale = 1.0
        team = body.get('team') or None
        try:
            self.team_id = int(team) if team else None
        except (TypeError, ValueError):
            self.team_id = None
        self.formation = body.get('formation') if body.get('formation') in SV.FORMATIONS else '4-3-3'
        self.profiles, self.info = self.data['profiles'], self.data['info']
        self.meta = _meta(self.info, self.today)
        self.sch = schedule()
        # 피로도·경고 누적은 '모의 경기' 에서 쌓인 기록만 반영한다. (베스트11 화면은 읽기만 한다)
        self.managed = bool(body.get('use_fatigue'))
        self.target = _parse_date(body.get('date'), self.today)
        # 남은 정규 라운드 = 기준일 당일 이후에 열리는 라운드
        self.first = MG.first_unplayed_round(self.sch, self.target - timedelta(days=1)) if self.sch else None
        self.log = clean_log(body.get('mock_log'))
        if self.managed:
            self.state = replay_mock(self.info, self.meta, self.log, self.target)
        else:
            self.state = {str(pid): {'fatigue': 0.0, 'yellow_acc': 0, 'streak': 0} for pid in self.info}

    # 대상 선수 풀 (구단 선택 시 그 구단, 아니면 리그 전체)
    def pool(self):
        return [p for p in self.profiles.values() if self.team_id is None or p['team_id'] == self.team_id]

    def adj(self, pid):
        """감독 모드일 때만 피로도·신중 플레이 효과를 반영한 능력."""
        base = self.ability.get(pid, 0.0)
        if not self.managed:
            return base
        s = self.state.get(str(pid), {})
        return MG.adjusted_ability(base, s.get('fatigue', 0.0), s.get('yellow_acc', 0))

    def lineup_profiles(self, ids):
        return [self.profiles[i] for i in ids if i in self.profiles]

    def score_lineup(self, lineup):
        chem = CH.lineup_chemistry(lineup, scale=self.chem_scale)
        total = sum(CH.final_score(self.adj(p['id']), chem['players'][p['id']]['bonus']) for p in lineup)
        return total, chem

    def badges(self, pid):
        i = self.info[pid]
        s = self.state.get(str(pid), {})
        risk = MG.card_probability(i['yellow'], i['red'], i['minutes'])
        out = {'risk': risk, 'risk_label': MG.card_risk_label(risk), 'badges': []}
        if self.managed:
            out['badges'] = MG.availability(s, risk)['badges']
            out['fatigue'] = round(s.get('fatigue', 0.0))
            out['yellow_acc'] = s.get('yellow_acc', 0)
        if self.profiles[pid]['low_minutes']:
            out['badges'].append('출전 적음')
        gp = i['minutes'] / i['games'] if i['games'] else 0
        out['avg_minutes'] = round(gp)
        return out

    def brief(self, pid):
        i = self.info[pid]
        p = self.profiles[pid]
        return {'id': pid, 'name': i['name'], 'position': i['position'], 'team': i['team'], 'team_id': i['team_id'],
                'number': i['number'], 'photo': i['photo'], 'team_logo': i['team_logo'], 'minutes': i['minutes'], 'low_minutes': p['low_minutes'],
                'ability': round(self.ability.get(pid, 0.0), 1), 'adjusted': round(self.adj(pid), 1)}


# ---------------------------------------------------------------- API 로직

def api_init(body):
    c = Ctx(body)
    teams = sorted({(i['team_id'], i['team']) for i in c.info.values() if i['team_id']}, key=lambda x: x[1])
    pred, err = _forecast_tools()
    club = c.data['club']
    return {
        'teams': [{'id': t, 'name': n, 'style': club[t]['label'] if t in club else ''} for t, n in teams],
        'club_styles': [{'id': t, 'name': n, 'style': club[t]['label'], 'scores': club[t]['scores'], 'metrics': club[t]['metrics']}
                        for t, n in teams if t in club],
        'formations': SV.FORMATIONS,
        'presets': {k: v['label'] for k, v in PRESETS.items()},
        'metrics': {pos: [{'key': m, 'label': METRIC_LABELS.get(m, m), 'weight': round(w, 1)} for m, w in BASE_WEIGHTS[pos].items()]
                    for pos in BASE_WEIGHTS},
        'today': c.today.isoformat(),
        'prediction': {'available': pred is not None, 'trained_through': pred[2]['trained_through'] if pred else None, 'error': err},
        'schedule_note': '일정 파일 기준일은 파일을 받은 시점입니다. 오늘 날짜 이후 경기만 남은 라운드로 봅니다.',
    }


def _default_lineup(c):
    cnt = SV.FORMATIONS[c.formation]
    pool = c.pool()
    ids = []
    for pos in ('GK', 'DF', 'MF', 'FW'):
        cands = [p for p in pool if p['position'] == pos]
        cands.sort(key=lambda p: -(c.adj(p['id']) * (0.85 if p['low_minutes'] else 1.0)))
        ids += [p['id'] for p in cands[:cnt[pos]]]
    return ids


def api_lineup(body):
    """기본 라인업(능력 순) 또는 케미까지 반영해 다듬은 라인업(optimize=true)."""
    c = Ctx(body)
    ids = _default_lineup(c)
    if body.get('optimize'):
        lineup = c.lineup_profiles(ids)
        pool = c.pool()
        for _ in range(2):
            changed = False
            for idx in range(len(lineup)):
                cur_total, _chem = c.score_lineup(lineup)
                taken = {p['id'] for p in lineup}
                cands = [p for p in pool if p['position'] == lineup[idx]['position'] and p['id'] not in taken]
                cands.sort(key=lambda p: -c.adj(p['id']))
                best, best_total = None, cur_total
                for cand in cands[:8]:
                    trial = list(lineup)
                    trial[idx] = cand
                    t, _chem = c.score_lineup(trial)
                    if t > best_total + 1e-6:
                        best, best_total = cand, t
                if best:
                    lineup[idx] = best
                    changed = True
            if not changed:
                break
        ids = [p['id'] for p in lineup]
    return {'lineup': ids}


def _validate_lineup(c, body):
    ids = []
    for x in body.get('lineup') or []:
        try:
            x = int(x)
        except (TypeError, ValueError):
            continue
        if x in c.profiles and x not in ids:
            ids.append(x)
    return ids


def api_evaluate(body):
    c = Ctx(body)
    ids = _validate_lineup(c, body)
    lineup = c.lineup_profiles(ids)
    if len(lineup) != 11:
        return {'error': '선수 11명이 필요합니다.'}
    total, chem = c.score_lineup(lineup)
    players = []
    for p in lineup:
        pid = p['id']
        cp = chem['players'][pid]
        d = c.brief(pid)
        d.update(c.badges(pid))
        d['chem_bonus'] = cp['bonus']
        d['final'] = round(CH.final_score(c.adj(pid), cp['bonus']), 1)
        d['partners'] = [{'id': q['id'], 'name': q['name'], 'score': q['score'], 'tier': q['tier'], 'reasons': q['reasons']}
                         for q in cp['partners'][:3]]
        players.append(d)

    # 추천: 이 라인업 밖에서 라인업 선수와 케미가 좋은 선수
    taken = set(ids)
    recs = []
    for p in lineup:
        found = CH.recommend_partners(p, [q for q in c.pool() if q['id'] not in taken], k=1)
        if found:
            f = found[0]
            recs.append({'for_id': p['id'], 'for_name': p['name'], 'id': f['id'], 'name': f['name'], 'position': f['position'],
                         'score': f['score'], 'reasons': f['reasons'], 'low_minutes': f['low_minutes']})
    recs.sort(key=lambda r: -r['score'])

    # 분석
    ability_adj = {pid: c.adj(pid) for pid in c.profiles}
    irr_pool = c.pool()
    irr = AN.irreplaceability(lineup, irr_pool, ability_adj, {}, c.chem_scale)
    refs = {}
    for pos in ('FW', 'MF', 'DF', 'GK'):
        refs[pos] = [c.ability[q['id']] for q in c.profiles.values() if q['position'] == pos and q['minutes'] >= CH.REFERENCE_MIN_MINUTES]
    ability_for_report = {pid: c.ability.get(pid, 0.0) for pid in c.profiles}
    report = AN.lineup_report(lineup, ability_for_report, c.state, c.meta, chem, irr, refs, c.today)

    opp_name = next((i['team'] for i in c.info.values() if i['team_id'] == c.opponent), None) if c.opponent else None
    out = {'players': players, 'total': round(total, 1), 'chem_team': chem['team_score'], 'recommend': recs[:5],
           'irreplaceability': irr['players'], 'report': report, 'managed': c.managed,
           'opponent': {'name': opp_name, 'reasons': c.opp_reasons, 'mult': c.opp_mult} if c.opponent else None}
    return out          # 경기·일정·피로와 관련된 분석(다음 상대, 로테이션)은 모의 경기 화면의 api_schedule 이 맡는다


def _outlook(c, lineup):
    if not c.team_id:
        return {'available': False, 'reason': '구단을 선택하면 그 구단의 다음 상대를 분석합니다.'}
    pred, err = _forecast_tools()
    if pred is None or not c.sch:
        return {'available': False, 'reason': err or '일정/예측 데이터를 불러오지 못했습니다.'}
    if not c.first:
        return {'available': False, 'reason': '기준일 이후에 남은 정규 라운드가 없습니다.'}
    MP, matches, bundle, ids = pred
    team_short = next((i['team_short'] for i in c.info.values() if i['team_id'] == c.team_id), None)
    if team_short not in ids:
        return {'available': False, 'reason': '예측 모델에 없는 구단입니다.'}

    def fc(h, a, d):
        return MP.forecast(matches, bundle, ids[h], ids[a], d)

    ref_pool = [q for q in c.profiles.values() if q['minutes'] >= CH.REFERENCE_MIN_MINUTES]
    ref = sum(c.ability[q['id']] for q in ref_pool) / max(1, len(ref_pool))
    mean = sum(c.adj(p['id']) for p in lineup) / len(lineup)
    factor = AN.lineup_strength_factor(mean, ref)
    rows = AN.opponent_outlook(c.sch['fixtures'], team_short, fc, c.first, 5, factor, MP.poisson_probabilities)
    return {'available': True, 'rows': rows, 'factor': round(factor, 3), 'trained_through': bundle['trained_through'],
            'note': '예측 모델은 학습 마지막 날짜 이후 경기만 계산합니다. 라인업 보정은 실험 기능이며 최대 ±10% 입니다.'}


def _rotation(c, lineup):
    """남은 정규 라운드 로테이션 계획. 지금까지 모의 경기로 쌓인 피로(target 날짜 기준)에서 출발한다."""
    if not c.sch or not c.first:
        return None
    team = [p for p in c.profiles.values() if p['team_id'] == c.team_id]
    bench = [p for p in team if p['id'] not in {x['id'] for x in lineup}]
    rounds = [r for r in sorted(c.sch['rounds']) if r >= c.first]
    ability_adj = {pid: c.ability.get(pid, 0.0) for pid in c.profiles}
    team_short = next((i['team_short'] for i in c.info.values() if i['team_id'] == c.team_id), None)
    # prev_round = first 이므로 첫 라운드 앞의 회복일은 0일 (이미 target 날짜까지 회복한 상태에서 시작)
    res = AN.plan_rotation(lineup, bench, c.state, c.meta, rounds, ability_adj, c.first, c.sch)
    names = {pid: c.info[pid]['name'] for pid in c.info}
    for r in res['rounds']:
        r['lineup_names'] = [names[i] for i in r['lineup']]
    res['team'] = team_short
    return res


def api_condition(body):
    """
    모의 경기 화면용: 이 날짜에 이 선수들의 피로 상태. 피로가 많으면 '안 좋음' 컨디션을 제안한다.
    body: {mock_log:[{date,ids}], date:'YYYY-MM-DD', ids:[선수ID...]}
    """
    info = _load()['info']
    target = _parse_date(body.get('date'), date.today())
    meta = _meta(info, target)
    state = replay_mock(info, meta, clean_log(body.get('mock_log')), target)
    players = {}
    for x in (body.get('ids') or [])[:40]:
        try:
            pid = int(x)
        except (TypeError, ValueError):
            continue
        if pid not in info:
            continue
        s = state[str(pid)]
        risk = MG.card_probability(info[pid]['yellow'], info[pid]['red'], info[pid]['minutes'])
        tier = MG.fatigue_tier(s['fatigue'])
        players[pid] = {'fatigue': round(s['fatigue']), 'label': tier['label'], 'streak': s['streak'],
                        'badges': MG.availability(s, risk)['badges'],
                        'suggest_bad': s['fatigue'] >= CONDITION_BAD_FATIGUE}
    return {'players': players, 'date': target.isoformat(), 'records': len(clean_log(body.get('mock_log'))),
            'bad_from': CONDITION_BAD_FATIGUE}


def api_schedule(body):
    """
    모의 경기 화면용: 한 팀 선발 11명 기준으로 남은 정규 일정 예상(다음 상대)과 로테이션 계획.
    body: {mock_log:[{date,ids}], date:'YYYY-MM-DD', ids:[선수ID 11명]}
    피로는 모의 경기 기록을 기준으로 하고, 팀은 선수들의 소속으로 정한다.
    """
    b = dict(body, use_fatigue=True)
    probe = _load()
    ids = []
    for x in (body.get('ids') or [])[:20]:
        try:
            x = int(x)
        except (TypeError, ValueError):
            continue
        if x in probe['profiles'] and x not in ids:
            ids.append(x)
    if len(ids) != 11:
        return {'error': '선수 11명이 필요합니다.'}
    teams = [probe['info'][i]['team_id'] for i in ids]
    team_id = max(set(teams), key=teams.count)
    b['team'] = team_id
    c = Ctx(b)
    lineup = c.lineup_profiles(ids)
    return {'team': c.info[ids[0]]['team'] if teams.count(team_id) == len(teams) else '여러 구단 혼합',
            'mixed': teams.count(team_id) != len(teams),
            'outlook': _outlook(c, lineup), 'rotation': _rotation(c, lineup), 'date': c.target.isoformat()}


def api_candidates(body):
    """교체 후보: out_id 자리에 넣었을 때 라인업 총점이 높은 순. 맨 위가 '추천'이다."""
    c = Ctx(body)
    ids = _validate_lineup(c, body)
    try:
        out_id = int(body.get('out_id'))
    except (TypeError, ValueError):
        return {'error': 'out_id 가 필요합니다.'}
    if out_id not in ids:
        return {'error': '라인업에 없는 선수입니다.'}
    lineup = c.lineup_profiles(ids)
    idx = ids.index(out_id)
    pos = lineup[idx]['position']
    base_total, _chem = c.score_lineup(lineup)
    taken = set(ids)
    cands = [p for p in c.pool() if p['position'] == pos and p['id'] not in taken]
    cands.sort(key=lambda p: -c.adj(p['id']))
    rows = []
    for cand in cands[:CANDIDATE_LIMIT * 2]:
        trial = list(lineup)
        trial[idx] = cand
        t, chem = c.score_lineup(trial)
        cp = chem['players'][cand['id']]
        d = c.brief(cand['id'])
        d.update(c.badges(cand['id']))
        d.update(chem_bonus=cp['bonus'], delta=round(t - base_total, 1), final=round(CH.final_score(c.adj(cand['id']), cp['bonus']), 1),
                 partners=[{'id': q['id'], 'name': q['name'], 'score': q['score']} for q in cp['partners'][:2]])
        rows.append(d)
    rows.sort(key=lambda d: -d['delta'])
    rows = rows[:CANDIDATE_LIMIT]
    for k, d in enumerate(rows):
        d['recommended'] = k < 3 and d['delta'] > 0
    return {'candidates': rows, 'position': pos}



def api_formations(body):
    """포메이션별 점수. 같은 설정(가중치·케미·구단)에서 6개 포메이션의 자동 선발 라인업을 만들어 점수로 비교한다.
    - 점수 = 선수별 최종 점수(능력 + 케미, 상한 200점)의 합.
    - 포메이션마다 포지션 인원이 달라 합계만 보면 인원이 많은 쪽이 유리하므로,
      '리그 같은 포지션 주전급(450분 이상) 평균 대비 +몇 점'(vs_avg)을 순위 기준으로 쓴다. 백분위는 쓰지 않는다."""
    c = Ctx(body)
    ref = {}
    for pos in ('FW', 'MF', 'DF', 'GK'):
        vals = [c.ability[q['id']] for q in c.profiles.values() if q['position'] == pos and q['minutes'] >= CH.REFERENCE_MIN_MINUTES]
        ref[pos] = sum(vals) / len(vals) if vals else 0.0
    rows = []
    for f in SV.FORMATIONS:
        c.formation = f
        ids = _default_lineup(c)
        lineup = c.lineup_profiles(ids)
        if len(lineup) != 11:
            continue
        total, chem = c.score_lineup(lineup)
        vs_avg = sum(CH.final_score(c.adj(p['id']), chem['players'][p['id']]['bonus']) - ref[p['position']] for p in lineup)
        rows.append({'formation': f, 'total': round(total, 1), 'avg': round(total / 11, 1), 'vs_avg': round(vs_avg, 1),
                     'chem_team': chem['team_score'], 'cap': CH.FINAL_SCORE_CAP})
    rows.sort(key=lambda r: -r['vs_avg'])
    for k, r in enumerate(rows):
        r['rank'] = k + 1
    return {'formations': rows, 'best': rows[0]['formation'] if rows else None}


def api_quality(body):
    """선수 기록 데이터 점검 리포트. 관리자 제외선수·테스트 선수를 포함한 DB 전체(2026 시즌, 출전 기록 있는 선수)를 본다."""
    qs = (PlayerStats.objects.filter(season=SEASON).select_related('player', 'player__team'))
    rows = []
    for st in qs:
        d = {f: getattr(st, f, None) for f in set(CH.STAT_FIELDS) | {'games', 'best11_count', 'mom', 'dribble_success', 'cross_attempt',
                                                                       'cross_success', 'tackle_attempt', 'tackle_success',
                                                                       'aerial_duel_attempt', 'aerial_duel_success',
                                                                       'ground_duel_attempt', 'ground_duel_success'}}
        pl = st.player
        d.update(id=pl.id, name=pl.name, team_id=pl.team_id, team=pl.team.team_name if pl.team_id else '',
                 position=pl.position, birth_date=pl.birth_date)
        rows.append(d)
    return QL.check(rows)
