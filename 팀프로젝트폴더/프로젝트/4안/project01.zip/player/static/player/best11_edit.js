/* 나만의 BEST11 (BEST11 화면 안에서 쓰는 도구 모음)
 *  - 가중치(프리셋·지표별 배율)·케미 중시·상대 맞춤을 이 화면에서 바로 조절한다. 바꾸면 선수 점수와 자동 선발이 다시 계산된다.
 *  - 카드의 점수 옆에 케미 가산점을 다른 색(초록=가산 / 빨강=감점)으로 붙인다. 선수 팝업에는 이름 옆에 작게 표시한다.
 *  - 카드의 ⇄ 교체 버튼으로 같은 포지션 선수만 골라 바꿀 수 있다. (라인업 총점이 가장 많이 오르는 후보가 추천)
 *  - 선수 팝업의 'VS 비교'는 두 선수의 육각형 그래프를 색을 달리해 겹쳐 그리고, '보정 반영'을 켜면 케미·가중치·소표본 보정을 반영한 면을 점선으로 겹친다.
 *  - 포메이션 추천은 백분위가 아니라 점수(선수별 최종 점수, 상한 200점)로 비교한다.
 * 점수 계산은 모두 서버가 DB 기록으로 다시 한다. 내 설정·라인업은 이 브라우저(localStorage)에만 저장되고 서버 DB 는 바뀌지 않는다.
 * 계산이 끝나면 document 에 'b11:result' 이벤트를 보내 아래쪽 분석 패널(lab.js)이 같은 결과를 보여 준다.
 */
(function () {
  'use strict';
  var script = document.currentScript;
  if (!script) return;
  var D = script.dataset;
  var URLS = { evaluate: D.evaluateUrl, candidates: D.candidatesUrl, lineup: D.lineupUrl, formations: D.formationsUrl, init: D.initUrl };
  var INFO = D.infoBase || '/player/info/';
  var field = document.querySelector('.football-field');
  if (!field || !URLS.evaluate || !URLS.candidates) return;
  var cards = Array.prototype.slice.call(field.querySelectorAll('.player-card'));
  if (cards.length !== 11) return;                      // 포메이션을 만들 수 없는 화면이면 사용하지 않음

  var KEY = 'kleague-my-best11-v1', SKEY = 'kleague-b11-settings-v1';
  var POS_ORDER = ['FW', 'MF', 'DF', 'GK'], POS_LABEL = { FW: '공격수', MF: '미드필더', DF: '수비수', GK: '골키퍼' };
  var teamSel = document.getElementById('teamSelect'), formSel = document.getElementById('formationSelect');
  function team() { return teamSel ? teamSel.value : ''; }
  function formation() { return formSel ? formSel.value : '4-3-3'; }
  function storeKey() { return (team() || 'all') + '|' + formation(); }
  function csrfToken() { var i = document.querySelector('input[name=csrfmiddlewaretoken]'); return i ? i.value : ''; }
  function sign(n) { return (n >= 0 ? '+' : '') + n; }
  function num1(n) { return Math.round(n * 10) / 10; }
  function el(tag, attrs, kids) {
    var e = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'text') e.textContent = attrs[k]; else if (k === 'class') e.className = attrs[k];
      else if (k.indexOf('on') === 0) e.addEventListener(k.slice(2), attrs[k]); else e.setAttribute(k, attrs[k]);
    });
    (kids || []).forEach(function (c) { if (c != null) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }
  function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); return n; }
  function post(url, body) {
    return fetch(url, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken() }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().then(function (j) { if (!r.ok || j.error) throw new Error(j.error || '요청 실패'); return j; }); });
  }
  function readJSON(k, d) { try { return JSON.parse(localStorage.getItem(k) || 'null') || d; } catch (e) { return d; } }
  function writeJSON(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* 저장 불가여도 동작 */ } }

  function cardId(card) {
    var a = card.querySelector('.player-popup-link');
    var m = a && /openPlayerModal\((\d+)\)/.exec(a.getAttribute('onclick') || '');
    return m ? Number(m[1]) : null;
  }
  var originalIds = cards.map(cardId);
  if (originalIds.some(function (x) { return x == null; })) return;
  var ids = originalIds.slice();
  var last = null;                     // 마지막 평가 결과
  var INIT = null;                     // 서버 초기 정보 (구단·프리셋·지표)
  var ST = readJSON(SKEY, {});
  var S = { preset: ST.preset || 'default', mult: ST.mult || {}, chem: typeof ST.chem === 'number' ? ST.chem : 1, exp: typeof ST.exp === 'number' ? ST.exp : 1.5, opponent: ST.opponent || '' };
  function saveSettings() { writeJSON(SKEY, S); }
  function isDefaultSettings() { return S.preset === 'default' && !Object.keys(S.mult).length && S.chem === 1 && S.exp === 1.5 && !S.opponent; }
  function params() { return { team: team(), formation: formation(), lineup: ids, preset: S.preset, mult: S.mult, chem_scale: S.chem, exp_scale: S.exp, opponent: S.opponent || null }; }
  function isCustom() { return ids.some(function (x, i) { return x !== autoIds[i]; }); }
  var autoIds = originalIds.slice();   // '자동 선발' 기준 라인업 (설정이 기본이면 화면이 원래 보여 준 선수, 아니면 서버가 가중치로 다시 뽑은 선수)

  /* ---------- 화면 요소 ---------- */
  var tools = el('div', { class: 'b11-tools' });
  var bar = el('div', { class: 'b11-bar' });
  field.parentNode.insertBefore(tools, field);
  field.parentNode.insertBefore(bar, field);
  cards.forEach(function (card, i) {
    card.style.position = card.style.position || 'relative';
    var b = el('button', { type: 'button', class: 'b11-swap', title: '이 자리 선수 교체', 'aria-label': '선수 교체', text: '⇄ 교체' });
    b.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); openCands(i); });
    card.appendChild(b);
  });
  var modal = el('div', { class: 'lab-modal b11-modal', hidden: '' }, [
    el('div', { class: 'lab-modal-box', role: 'dialog', 'aria-modal': 'true' }, [
      el('div', { class: 'lab-modal-head' }, [el('b', { id: 'b11Title', text: '' }), el('button', { type: 'button', id: 'b11Close', 'aria-label': '닫기', text: '✕' })]),
      el('div', { id: 'b11Body' })])]);
  document.body.appendChild(modal);
  function openModal(title, node, wide) {
    modal.querySelector('#b11Title').textContent = title;
    clear(modal.querySelector('#b11Body')).appendChild(node);
    modal.querySelector('.lab-modal-box').className = 'lab-modal-box' + (wide ? ' wide' : '');
    modal.hidden = false;
  }
  function closeModal() { modal.hidden = true; }
  modal.addEventListener('click', function (e) { if (e.target === modal) closeModal(); });
  modal.querySelector('#b11Close').addEventListener('click', closeModal);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });
  function badge(t) { return el('span', { class: 'lab-badge' + (t === '출전 적음' ? ' soft' : ''), text: t }); }

  /* ---------- 가중치 도구 모음 ---------- */
  var presetBox = el('span', { class: 'b11-presets' });
  var chemVal = el('b', { text: S.chem.toFixed(2).replace(/0$/, '') + '×' });
  var chemInp = el('input', { type: 'range', min: '0', max: '2', step: '0.25', value: String(S.chem), 'aria-label': '케미 중시' });
  var expVal = el('b', { text: S.exp.toFixed(2).replace(/0$/, '') + '×' });
  var expInp = el('input', { type: 'range', min: '0', max: '2', step: '0.25', value: String(S.exp), 'aria-label': '경험 중시' });
  var oppSel = el('select', { 'aria-label': '상대 맞춤' }, [el('option', { value: '', text: '선택 안 함' })]);
  var oppNote = el('span', { class: 'lab-muted' });
  var metricsBox = el('div', { class: 'lab-metrics' });
  function buildTools() {
    clear(tools);
    tools.appendChild(el('div', { class: 'b11-tools-row' }, [
      el('b', { text: '가중치' }), presetBox,
      el('label', { class: 'b11-slider' }, ['케미 중시 ', chemInp, ' ', chemVal]),
      el('label', { class: 'b11-slider', title: '출전시간이 적은 선수의 점수를 깎는 정도 (0 = 보정 없음)' }, ['경험(출전시간) 중시 ', expInp, ' ', expVal]),
      el('label', {}, ['상대 맞춤 ', oppSel]), oppNote]));
    tools.appendChild(el('div', { class: 'b11-tools-row' }, [
      el('button', { type: 'button', text: '이 가중치로 선발', title: '지금 가중치로 선수를 다시 뽑습니다', onclick: function () { pick(false); } }),
      el('button', { type: 'button', text: '케미 반영 최적화', title: '케미까지 반영해 선수를 다듬습니다', onclick: function () { pick(true); } }),
      el('button', { type: 'button', text: '포메이션 추천', title: '이 구단·가중치에서 점수가 가장 높은 포메이션', onclick: openFormations }),
      el('span', { class: 'lab-muted', text: '카드 숫자 = 능력 점수, 옆의 색 숫자 = 케미 가산점' })]));
    var det = el('details', { class: 'lab-detail' }, [el('summary', { text: '지표별 가중치 자세히 (배율 0~3×)' }), metricsBox]);
    tools.appendChild(det);
  }
  function fmtMult(v) { return v.toFixed(2).replace(/0$/, '') + '×'; }
  function fillTools() {
    clear(presetBox);
    Object.keys(INIT.presets).forEach(function (k) {
      presetBox.appendChild(el('button', { type: 'button', 'data-k': k, class: k === S.preset ? 'on' : '', text: INIT.presets[k], onclick: function () { setPreset(k); } }));
    });
    INIT.teams.forEach(function (t) { oppSel.appendChild(el('option', { value: t.id, text: t.name + (t.style ? ' (' + t.style + ')' : '') })); });
    oppSel.value = S.opponent;
    clear(metricsBox);
    POS_ORDER.forEach(function (pos) {
      var fs = el('fieldset', {}, [el('legend', { text: POS_LABEL[pos] })]);
      INIT.metrics[pos].forEach(function (x) {
        var cur = S.mult[x.key] != null ? S.mult[x.key] : 1;
        var out = el('b', { text: fmtMult(cur) });
        var inp = el('input', { type: 'range', min: '0', max: '3', step: '0.25', value: String(cur), 'data-key': x.key });
        inp.addEventListener('input', function () { out.textContent = fmtMult(parseFloat(inp.value)); });
        inp.addEventListener('change', function () { S.mult[x.key] = parseFloat(inp.value); saveSettings(); settingsChanged(); });
        fs.appendChild(el('label', {}, [x.label + ' (' + x.weight + ')', inp, out]));
      });
      metricsBox.appendChild(fs);
    });
    chemInp.addEventListener('input', function () { chemVal.textContent = fmtMult(parseFloat(chemInp.value)); });
    chemInp.addEventListener('change', function () { S.chem = parseFloat(chemInp.value); saveSettings(); settingsChanged(); });
    expInp.addEventListener('input', function () { expVal.textContent = fmtMult(parseFloat(expInp.value)); });
    expInp.addEventListener('change', function () { S.exp = parseFloat(expInp.value); saveSettings(); settingsChanged(); });
    oppSel.addEventListener('change', function () { S.opponent = oppSel.value; saveSettings(); settingsChanged(); });
  }
  function setPreset(k) {
    S.preset = k; S.mult = {}; saveSettings();
    Array.prototype.forEach.call(presetBox.children, function (b) { b.className = b.getAttribute('data-k') === k ? 'on' : ''; });
    Array.prototype.forEach.call(metricsBox.querySelectorAll('input'), function (i) { i.value = '1'; i.nextSibling.textContent = '1×'; });
    settingsChanged();
  }

  /* ---------- 서버 호출 (계산 중에 바뀐 설정은 끝난 뒤 한 번 더 계산) ---------- */
  var busy = false, again = null;
  function run(fn) {
    if (busy) { again = fn; return; }
    busy = true; bar.classList.add('busy');
    fn().catch(showErr).then(function () { busy = false; bar.classList.remove('busy'); if (again) { var f = again; again = null; run(f); } });
  }
  function settingsChanged() {
    // 내가 직접 바꾼 라인업이 있으면 선수는 그대로 두고 점수만 다시 계산, 아니면 가중치로 다시 선발
    run(function () { return isCustom() ? evaluate() : autoPick(false); });
  }
  function autoPick(optimize) {
    var b = params(); b.optimize = !!optimize; delete b.lineup;
    return post(URLS.lineup, b).then(function (r) { autoIds = r.lineup.slice(); ids = r.lineup.slice(); save(); return evaluate(); });
  }
  function pick(optimize) { run(function () { return autoPick(optimize); }); }
  function evaluate() { return post(URLS.evaluate, params()).then(render); }

  /* ---------- 카드 다시 그리기 ---------- */
  function paint(card, p) {
    var a = card.querySelector('.player-popup-link');
    a.setAttribute('onclick', 'openPlayerModal(' + p.id + '); return false;');
    var photo = card.querySelector('.player-photo'); clear(photo);
    if (p.photo) photo.appendChild(el('img', { src: p.photo, alt: p.name })); else photo.appendChild(el('div', { class: 'no-photo', text: 'NO PHOTO' }));
    card.querySelector('.player-name').textContent = p.name;
    var tn = card.querySelector('.team-name'); clear(tn);
    if (p.team_logo) tn.appendChild(el('img', { src: p.team_logo, alt: p.team, class: 'team-mini-logo' }));
    tn.appendChild(el('span', { text: p.team + ' · ' + p.position }));
    var sc = card.querySelector('.player-score'); clear(sc);
    sc.appendChild(document.createTextNode('BEST11 ' + p.ability + '점'));
    sc.appendChild(el('span', { class: 'b11-cn ' + (p.chem_bonus > 0 ? 'pos' : p.chem_bonus < 0 ? 'neg' : 'zero'), text: ' ' + sign(p.chem_bonus),
      title: '케미 가산점 ' + sign(p.chem_bonus) + ' → 최종 ' + p.final + '점' }));
    var old = card.querySelector('.b11-chem'); if (old) old.remove();
    var mark = card.querySelector('.b11-mark'); if (mark) mark.remove();
    if (p.id !== autoIds[cards.indexOf(card)]) a.appendChild(el('div', { class: 'b11-mark', text: '내 선택' }));
  }
  function render(r) {
    last = r;
    r.players.forEach(function (p, i) { paint(cards[i], p); });
    var changed = isCustom();
    var parts = [
      el('span', { text: changed ? '내 BEST11 (직접 교체함)' : (isDefaultSettings() ? 'BEST11 (자동 선발)' : 'BEST11 (가중치 적용 자동 선발)') }),
      el('span', { text: '라인업 총점 ' + r.total + ' · 팀 케미 평균 ' + sign(r.chem_team) }),
      el('span', { class: 'lab-muted', text: '카드의 ⇄ 교체 버튼으로 선수를 바꿀 수 있습니다' }),
      changed ? el('button', { type: 'button', text: '자동 선발로 되돌리기', onclick: reset }) : null,
      isDefaultSettings() ? null : el('button', { type: 'button', text: '가중치 초기화', onclick: resetSettings })];
    clear(bar);
    parts.filter(Boolean).forEach(function (n) { bar.appendChild(n); });
    oppNote.textContent = r.opponent ? r.opponent.name + ' 상대 맞춤: ' + (r.opponent.reasons.length ? r.opponent.reasons.join(' / ') : '조정할 규칙 없음') : '';
    document.dispatchEvent(new CustomEvent('b11:result', { detail: { result: r, params: params() } }));
    updateModalTag();
  }
  function save() {
    var o = readJSON(KEY, {});
    if (isCustom()) o[storeKey()] = ids; else delete o[storeKey()];
    writeJSON(KEY, o);
  }
  function reset() { run(function () { ids = autoIds.slice(); save(); return evaluate(); }); }
  function resetSettings() {
    S = { preset: 'default', mult: {}, chem: 1, exp: 1.5, opponent: '' }; saveSettings();
    chemInp.value = '1'; chemVal.textContent = '1×'; expInp.value = '1.5'; expVal.textContent = '1.5×'; oppSel.value = '';
    Array.prototype.forEach.call(presetBox.children, function (b) { b.className = b.getAttribute('data-k') === 'default' ? 'on' : ''; });
    Array.prototype.forEach.call(metricsBox.querySelectorAll('input'), function (i) { i.value = '1'; i.nextSibling.textContent = '1×'; });
    settingsChanged();
  }
  function showErr(e) { bar.appendChild(el('span', { class: 'lab-msg err', text: e.message })); }

  /* ---------- 교체 ---------- */
  function openCands(slot) {
    var box = el('div', {}, [el('p', { class: 'lab-muted', text: '불러오는 중…' })]);
    openModal(cards[slot].querySelector('.player-name').textContent + ' 교체 후보', box);
    var b = params(); b.out_id = ids[slot];
    post(URLS.candidates, b).then(function (r) {
      clear(box);
      box.appendChild(el('p', { class: 'lab-muted', text: '같은 포지션만 나옵니다. 라인업 총점(능력+케미)이 가장 많이 오르는 순서이고, 위쪽 후보가 추천입니다.' }));
      if (!r.candidates.length) box.appendChild(el('p', { text: '교체할 수 있는 선수가 없습니다.' }));
      r.candidates.forEach(function (c) {
        var d = c.delta;
        var kids = [el('div', {}, [el('b', { text: c.name }), ' ', el('span', { class: 'lab-muted', text: c.team + ' · BEST11 ' + c.ability + '점 ' }),
          el('span', { class: 'b11-cn ' + (c.chem_bonus > 0 ? 'pos' : c.chem_bonus < 0 ? 'neg' : 'zero'), text: sign(c.chem_bonus) }),
          c.recommended ? el('span', { class: 'lab-badge info', text: '추천' }) : null].concat(c.badges.map(badge)).concat(
          [c.partners.length ? el('div', { class: 'lab-muted', text: '케미: ' + c.partners.map(function (q) { return q.name; }).join(', ') }) : null])),
          el('div', {}, [el('span', { class: 'lab-delta ' + (d >= 0 ? 'pos' : 'neg'), text: sign(d) + ' ' }),
            el('button', { type: 'button', text: '교체', onclick: function () { choose(slot, c.id); } })])];
        box.appendChild(el('div', { class: 'lab-cand' + (c.recommended ? ' rec' : '') }, kids));
      });
    }).catch(function (e) { clear(box).appendChild(el('p', { class: 'lab-msg err', text: e.message })); });
  }
  function choose(slot, id) {
    ids[slot] = id; closeModal(); save();
    run(evaluate);
  }

  /* ---------- 포메이션 추천 (점수 기준) ---------- */
  function openFormations() {
    var box = el('div', {}, [el('p', { class: 'lab-muted', text: '계산 중…' })]);
    openModal('포메이션 추천', box, true);
    var b = params(); delete b.lineup;
    post(URLS.formations, b).then(function (r) {
      clear(box);
      var who = team() ? '선택한 구단' : '리그 전체';
      box.appendChild(el('p', { class: 'lab-muted', text: who + '에서 포메이션별로 자동 선발한 라인업을 같은 가중치로 계산했습니다. 점수는 선수별 최종 점수(능력 + 케미, 상한 ' + (r.formations[0] ? r.formations[0].cap : 200) +
        '점)이고, 포메이션마다 포지션 인원이 달라서 "리그 같은 포지션 주전급 평균보다 몇 점 높은가"로 순위를 매깁니다. (백분위가 아닙니다)' }));
      var max = Math.max.apply(null, r.formations.map(function (x) { return Math.abs(x.vs_avg); }).concat([1]));
      var tb = el('table', { class: 'b11-ftable' }, [el('tr', {}, ['순위', '포메이션', '평균 대비 점수', '선수당', '총점', '선수 평균', '케미', ''].map(function (h) { return el('th', { text: h }); }))]);
      r.formations.forEach(function (f) {
        var cur = f.formation === formation();
        tb.appendChild(el('tr', { class: cur ? 'cur' : '' }, [
          el('td', { text: String(f.rank) }),
          el('td', {}, [el('b', { text: f.formation }), f.rank === 1 ? el('span', { class: 'lab-badge info', text: '추천' }) : null, cur ? el('span', { class: 'lab-badge soft', text: '현재' }) : null]),
          el('td', {}, [el('span', { class: 'lab-bar', style: 'width:' + Math.max(2, Math.round(Math.abs(f.vs_avg) / max * 120)) + 'px' }), ' ' + sign(f.vs_avg) + '점']),
          el('td', { text: sign(num1(f.vs_avg / 11)) }), el('td', { text: String(f.total) }), el('td', { text: String(f.avg) }), el('td', { text: sign(f.chem_team) }),
          el('td', {}, [cur ? null : el('button', { type: 'button', text: '이 포메이션', onclick: function () { useFormation(f.formation); } })])]));
      });
      box.appendChild(tb);
      box.appendChild(el('p', { class: 'lab-muted', text: '실제 구단이 쓰는 포메이션 기록은 데이터에 없어서, 이 구단 선수들의 기록으로 계산한 "잘 맞는 포메이션"입니다. 선수 기록이 적은 구단은 오차가 큽니다.' }));
    }).catch(function (e) { clear(box).appendChild(el('p', { class: 'lab-msg err', text: e.message })); });
  }
  function useFormation(f) {
    closeModal();
    if (!formSel) return;
    formSel.value = f;
    formSel.dispatchEvent(new Event('change', { bubbles: true }));     // 화면의 기존 필터가 자동으로 다시 불러온다
  }

  /* ---------- 선수 팝업: 이름 옆 케미 표시 + VS 비교 ---------- */
  var curId = null;
  var nameEl = document.getElementById('modalPlayerName');
  var tag = el('span', { class: 'b11-mtag', hidden: '' });
  var vsBtn = el('button', { type: 'button', class: 'b11-vs', text: '⚔ VS 비교', onclick: function () { openCompare(curId); } });
  var tagWrap = el('span', { class: 'b11-mwrap' }, [tag, vsBtn]);
  function updateModalTag() {
    if (!nameEl) return;
    var p = last && last.players.filter(function (x) { return x.id === curId; })[0];
    tagWrap.hidden = curId == null;
    if (!p) { tag.hidden = true; return; }
    tag.hidden = false;
    tag.className = 'b11-mtag ' + (p.chem_bonus > 0 ? 'pos' : p.chem_bonus < 0 ? 'neg' : 'zero');
    tag.textContent = '케미 ' + sign(p.chem_bonus);
    tag.title = '능력 ' + p.ability + ' + 케미 ' + sign(p.chem_bonus) + ' = 최종 ' + p.final + '점' + (p.partners.length ? ' · 잘 맞는 선수: ' + p.partners.map(function (q) { return q.name; }).join(', ') : '');
  }
  if (nameEl && nameEl.parentNode) {
    if (window.getComputedStyle(nameEl).display === 'block') nameEl.style.display = 'inline-block';   // 이름 바로 옆에 표시되도록
    nameEl.parentNode.insertBefore(tagWrap, nameEl.nextSibling);
    tagWrap.hidden = true;
    var orig = window.openPlayerModal;
    if (typeof orig === 'function') {
      window.openPlayerModal = function (id) { curId = Number(id); updateModalTag(); return orig.apply(this, arguments); };
    }
    new MutationObserver(function () { updateModalTag(); }).observe(nameEl, { childList: true, characterData: true, subtree: true });
  }

  var infoCache = {};
  function getInfo(id) {
    if (infoCache[id]) return Promise.resolve(infoCache[id]);
    return fetch(INFO + id + '/', { credentials: 'same-origin' }).then(function (r) { if (!r.ok) throw new Error('선수 정보를 불러오지 못했습니다.'); return r.json(); })
      .then(function (j) { if (j.success === false) throw new Error(j.message || '기록이 없는 선수입니다.'); infoCache[id] = j; return j; });
  }
  var COL = { a: '#2563eb', b: '#ea580c' };
  var SVGNS = 'http://www.w3.org/2000/svg';
  function s(tag, attrs, kids) {
    var e = document.createElementNS(SVGNS, tag);
    Object.keys(attrs || {}).forEach(function (k) { e.setAttribute(k, attrs[k]); });
    (kids || []).forEach(function (c) { e.appendChild(c); });
    return e;
  }
  function radarSvg(labels, series) {
    var cx = 210, cy = 170, R = 112, n = labels.length;
    function pt(i, v) { var a = -Math.PI / 2 + i * 2 * Math.PI / n, r = R * Math.max(0, Math.min(100, v)) / 100; return [cx + r * Math.cos(a), cy + r * Math.sin(a)]; }
    var svg = s('svg', { viewBox: '0 0 420 340', class: 'b11-radar', role: 'img', 'aria-label': '선수 비교 육각형 그래프' });
    [25, 50, 75, 100].forEach(function (lv) {
      svg.appendChild(s('polygon', { points: labels.map(function (_, i) { return pt(i, lv).join(','); }).join(' '), fill: 'none', stroke: '#d1d5db', 'stroke-width': '1' }));
    });
    labels.forEach(function (lb, i) {
      var e = pt(i, 100), t = pt(i, 122);
      svg.appendChild(s('line', { x1: cx, y1: cy, x2: e[0], y2: e[1], stroke: '#e5e7eb' }));
      var tx = s('text', { x: t[0], y: t[1], 'text-anchor': Math.abs(t[0] - cx) < 6 ? 'middle' : (t[0] > cx ? 'start' : 'end'), 'dominant-baseline': 'middle', 'font-size': '13', fill: '#374151' });
      tx.textContent = lb; svg.appendChild(tx);
    });
    series.forEach(function (sr, k) {
      var g = s('g', { class: 'b11-grow', style: 'animation-delay:' + (k * 0.08) + 's' });
      var pts = sr.vals.map(function (v, i) { return pt(i, v).join(','); }).join(' ');
      g.appendChild(s('polygon', { points: pts, fill: sr.dashed ? 'none' : sr.color, 'fill-opacity': sr.dashed ? '0' : '0.18', stroke: sr.color, 'stroke-width': sr.dashed ? '2' : '2.5',
        'stroke-dasharray': sr.dashed ? '6 4' : '', 'stroke-linejoin': 'round' }));
      if (!sr.dashed) sr.vals.forEach(function (v, i) { var p = pt(i, v); g.appendChild(s('circle', { cx: p[0], cy: p[1], r: '3.5', fill: sr.color })); });
      svg.appendChild(g);
    });
    return svg;
  }
  function correctedVals(vals, finalScore, baseScore) {
    // 보정 = 최종 점수(가중치·소표본 보정·케미 반영) ÷ 기본 BEST11 점수 비율을 각 축에 곱한 모양 (100 이 상한)
    var f = baseScore > 0 ? finalScore / baseScore : 1;
    return vals.map(function (v) { return Math.min(100, v * f); });
  }

  function openCompare(aId) {
    if (aId == null || !last) return;
    var slot = ids.indexOf(aId);
    var A = last.players.filter(function (x) { return x.id === aId; })[0];
    if (!A || slot < 0) { alert('이 선수는 현재 내 BEST11에 없어 비교할 수 없습니다.'); return; }
    var box = el('div', { class: 'b11-cmp' }, [el('p', { class: 'lab-muted', text: '불러오는 중…' })]);
    openModal(A.name + ' VS 비교', box, true);
    var b = params(); b.out_id = aId;
    post(URLS.candidates, b).then(function (r) {
      if (!r.candidates.length) { clear(box).appendChild(el('p', { text: '같은 포지션에 비교할 선수가 없습니다.' })); return; }
      var cmap = {}; r.candidates.forEach(function (c) { cmap[c.id] = c; });
      var cur = r.candidates[0].id, showFix = true;
      var sel = el('select', { 'aria-label': '비교할 선수' }, r.candidates.map(function (c) {
        return el('option', { value: c.id, text: c.name + ' (' + c.team + ') · ' + c.ability + '점 ' + sign(c.chem_bonus) + (c.recommended ? ' ★추천' : '') });
      }));
      var chk = el('input', { type: 'checkbox', id: 'b11Fix', checked: '' });
      var out = el('div', { class: 'b11-cmp-out' });
      var head = el('div', { class: 'b11-cmp-head' }, [
        el('label', {}, ['비교할 선수 ', sel]),
        el('label', { class: 'b11-fix', title: '케미·가중치·소표본 보정을 반영한 최종 점수 비율로 그래프를 키우거나 줄인 모양을 점선으로 겹칩니다' }, [chk, ' 보정 반영 (점선)'])]);
      clear(box); box.appendChild(head); box.appendChild(out);
      function draw() {
        var B = cmap[cur];
        clear(out).appendChild(el('p', { class: 'lab-muted', text: '불러오는 중…' }));
        Promise.all([getInfo(A.id), getInfo(B.id)]).then(function (res) {
          var ia = res[0], ib = res[1], labels = ia.radar_labels;
          var va = ia.radar_scores, vb = ib.radar_scores;
          var ba = ia.best11.score, bb = ib.best11.score;
          var series = [{ color: COL.a, vals: va }, { color: COL.b, vals: vb }];
          if (showFix) { series.push({ color: COL.a, vals: correctedVals(va, A.final, ba), dashed: true }); series.push({ color: COL.b, vals: correctedVals(vb, B.final, bb), dashed: true }); }
          function pcard(p, color, fin, chem, ab) {
            return el('div', { class: 'b11-pc', style: 'border-color:' + color }, [
              el('b', { style: 'color:' + color, text: p.name }), el('span', { class: 'lab-muted', text: ' ' + p.team + ' · ' + p.position }),
              el('div', {}, ['BEST11 ' + ab + '점 ', el('span', { class: 'b11-cn ' + (chem > 0 ? 'pos' : chem < 0 ? 'neg' : 'zero'), text: sign(chem) }), ' → 최종 ', el('b', { text: fin + '점' })])]);
          }
          var tb = el('table', { class: 'b11-cmp-table' }, [el('tr', {}, [el('th', { text: '항목' }), el('th', { text: A.name, style: 'color:' + COL.a }), el('th', { text: B.name, style: 'color:' + COL.b })])]);
          labels.forEach(function (lb, i) {
            tb.appendChild(el('tr', {}, [el('td', { text: lb }),
              el('td', { text: String(num1(va[i])) + (showFix ? ' → ' + num1(correctedVals(va, A.final, ba)[i]) : ''), class: va[i] >= vb[i] ? 'win' : '' }),
              el('td', { text: String(num1(vb[i])) + (showFix ? ' → ' + num1(correctedVals(vb, B.final, bb)[i]) : ''), class: vb[i] >= va[i] ? 'win' : '' })]));
          });
          clear(out);
          out.appendChild(el('div', { class: 'b11-cmp-grid' }, [
            el('div', {}, [radarSvg(labels, series),
              el('div', { class: 'b11-legend' }, [el('span', { class: 'sw', style: 'background:' + COL.a }), A.name, el('span', { class: 'sw', style: 'background:' + COL.b }), B.name,
                showFix ? el('span', { class: 'lab-muted', text: ' · 점선 = 보정 반영' }) : null])]),
            el('div', {}, [pcard(A, COL.a, A.final, A.chem_bonus, A.ability), pcard(B, COL.b, B.final, B.chem_bonus, B.ability), tb,
              el('p', { class: 'lab-muted', text: '실선 = 기록 그대로의 육각형. 점선 = 최종 점수 ÷ 기본 점수 비율을 곱한 보정 모양입니다. ' +
                (B.name + '로 바꾸면 라인업 총점이 ') + sign(B.delta) + '점 달라집니다. (케미 변화 포함)' }),
              el('button', { type: 'button', text: B.name + '(으)로 교체', onclick: function () { closeModal(); var pm = document.getElementById('playerModal'); if (pm) pm.style.display = 'none'; choose(slot, B.id); } })])]));
        }).catch(function (e) { clear(out).appendChild(el('p', { class: 'lab-msg err', text: e.message })); });
      }
      sel.addEventListener('change', function () { cur = Number(sel.value); draw(); });
      chk.addEventListener('change', function () { showFix = chk.checked; draw(); });
      draw();
    }).catch(function (e) { clear(box).appendChild(el('p', { class: 'lab-msg err', text: e.message })); });
  }

  /* ---------- 시작 ---------- */
  buildTools();
  var saved = readJSON(KEY, {})[storeKey()];
  function startAuto() {
    // 기본 설정이면 화면이 원래 보여 준 선수 그대로, 설정을 바꿔 둔 상태면 그 가중치로 다시 선발
    run(function () { return autoPick(false); });
  }
  function startSaved() {
    var keep = ids; ids = saved.map(Number);
    return post(URLS.evaluate, params()).then(function (r) {
      var okPos = r.players.every(function (p, i) { return p.position === cards[i].querySelector('.team-name span').textContent.split('·').pop().trim(); });
      if (!okPos) throw new Error('saved lineup mismatch');
      render(r);
    }).catch(function () { ids = keep; var o = readJSON(KEY, {}); delete o[storeKey()]; writeJSON(KEY, o); return autoPick(false); });
  }
  function begin() {
    if (Array.isArray(saved) && saved.length === 11) {
      // 직접 고른 라인업이 있으면 '자동 선발' 기준(autoIds)은 현재 설정으로 다시 구해 둔다
      run(function () {
        var b = params(); delete b.lineup;
        var base = post(URLS.lineup, b).then(function (r) { return r.lineup; });
        return base.then(function (a) { autoIds = a.slice(); return startSaved(); });
      });
    } else startAuto();
  }
  if (URLS.init) {
    post(URLS.init, {}).then(function (r) { INIT = r; fillTools(); begin(); })
      .catch(function (e) { bar.textContent = '가중치 도구를 불러오지 못했습니다: ' + e.message; });
  } else { run(evaluate); }
})();
